
class LoginLocator:
    username = "username"
    password = "password"
    button_login = "//button"
    error_message = "message"
    success_message = "successMessage"
    
